import re

class BaiInterpreter:
    def __init__(self):
        self.variables = {}
        self.output = []
    
    def tokenize(self, line):
        """Break line into tokens"""
        # Remove comments (anything after //)
        line = line.split('//')[0].strip()
        if not line:
            return []
        
        # Split by spaces but keep operators together
        tokens = line.split()
        return tokens
    
    def evaluate_expression(self, tokens):
        """Evaluate a mathematical expression or variable"""
        if len(tokens) == 1:
            token = tokens[0]
            # Check if it's a number
            try:
                return float(token)
            except ValueError:
                # Check if it's a variable
                if token in self.variables:
                    return self.variables[token]
                else:
                    raise Exception(f"Variable '{token}' dili pa gi-define (not defined)")
        
        # Handle operations: idugang x ug y
        if len(tokens) >= 3:
            operation = tokens[0]
            
            if operation in ['idugang', 'ikuha', 'ipilo', 'ibahin']:
                # Get operands
                left_val = self.get_value(tokens[1])
                right_val = self.get_value(tokens[3]) if len(tokens) > 3 and tokens[2] == 'ug' else self.get_value(tokens[2])
                
                if operation == 'idugang':
                    return left_val + right_val
                elif operation == 'ikuha':
                    return left_val - right_val
                elif operation == 'ipilo':
                    return left_val * right_val
                elif operation == 'ibahin':
                    if right_val == 0:
                        raise Exception("Dili pwede mag-divide by zero! (Cannot divide by zero!)")
                    return left_val / right_val
        
        raise Exception(f"Sayop ang syntax (Wrong syntax): {' '.join(tokens)}")
    
    def get_value(self, token):
        """Get numeric value from token (either number or variable)"""
        try:
            return float(token)
        except ValueError:
            if token in self.variables:
                return self.variables[token]
            else:
                raise Exception(f"Variable '{token}' dili pa gi-define (not defined)")
    
    def execute_line(self, line):
        """Execute a single line of Bai++ code"""
        tokens = self.tokenize(line)
        
        if not tokens:
            return None
        
        # Handle ibutang (variable assignment): ibutang x = 5
        if tokens[0] == 'ibutang':
            if len(tokens) < 4 or tokens[2] != '=':
                raise Exception("Sayop ang format sa ibutang. Gamita: ibutang x = 5")
            
            var_name = tokens[1]
            # Everything after = is the expression
            expr_tokens = tokens[3:]
            value = self.evaluate_expression(expr_tokens)
            self.variables[var_name] = value
            return None
        
        # Handle ipakita (print): ipakita x
        elif tokens[0] == 'ipakita':
            if len(tokens) < 2:
                raise Exception("Ipakita unsa? (Show what?) Gamita: ipakita x")
            
            # Can show variable or expression
            expr_tokens = tokens[1:]
            value = self.evaluate_expression(expr_tokens)
            self.output.append(str(value))
            return value
        
        # Handle standalone operations that should be stored
        elif tokens[0] in ['idugang', 'ikuha', 'ipilo', 'ibahin']:
            value = self.evaluate_expression(tokens)
            self.output.append(f"Resulta: {value}")
            return value
        
        else:
            raise Exception(f"Wala ma-kila ang command: {tokens[0]}")
    
    def run(self, code):
        """Run complete Bai++ program"""
        self.output = []
        self.variables = {}
        
        lines = code.strip().split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            try:
                self.execute_line(line)
            except Exception as e:
                self.output.append(f"ERROR sa line {line_num}: {str(e)}")
                return '\n'.join(self.output)
        
        return '\n'.join(self.output) if self.output else "Program nahuman nga walay output (Program completed with no output)"


# Test the interpreter
if __name__ == "__main__":
    interpreter = BaiInterpreter()
    
    # Example program
    test_program = """
    // Bai++ Calculator Test
    ibutang x = 10
    ibutang y = 5
    
    // Addition
    ipakita idugang x ug y
    
    // Subtraction
    ipakita ikuha x ug y
    
    // Multiplication
    ipakita ipilo x ug y
    
    // Division
    ipakita ibahin x ug y
    
    // Store result
    ibutang resulta = idugang x ug 15
    ipakita resulta
    """
    
    output = interpreter.run(test_program)
    print(output)