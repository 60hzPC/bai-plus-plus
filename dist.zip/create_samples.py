"""
Create sample .bai files for Bai++ users
Run this script to generate example programs
"""

sample_programs = {
    "basic_calculator.bai": """// Basic Calculator - Bai++
// Simple arithmetic operations

ibutang x = 100
ibutang y = 25

// Addition
ipakita idugang x ug y

// Subtraction
ipakita ikuha x ug y

// Multiplication
ipakita ipilo x ug y

// Division
ipakita ibahin x ug y
""",

    "shopping_total.bai": """// Shopping Total Calculator
// Calculate your total shopping expenses

// Item prices
ibutang sapatos = 1500
ibutang baju = 800
ibutang bag = 1200

// Calculate subtotal
ibutang subtotal = idugang sapatos ug baju
ibutang total = idugang subtotal ug bag

// Show the total
ipakita total

// Calculate with discount (10% off)
ibutang discount = ibahin total ug 10
ibutang final_price = ikuha total ug discount
ipakita final_price
""",

    "grade_calculator.bai": """// Grade Calculator
// Calculate average of test scores

// Test scores
ibutang quiz1 = 85
ibutang quiz2 = 90
ibutang quiz3 = 88

// Calculate total
ibutang total = idugang quiz1 ug quiz2
ibutang final_total = idugang total ug quiz3

// Calculate average (divide by 3)
ibutang average = ibahin final_total ug 3
ipakita average
""",

    "budget_planner.bai": """// Monthly Budget Planner
// Track your income and expenses

// Income
ibutang sweldo = 25000

// Expenses
ibutang kuryente = 2000
ibutang tubig = 500
ibutang kaon = 8000
ibutang transpo = 3000

// Calculate total expenses
ibutang expense1 = idugang kuryente ug tubig
ibutang expense2 = idugang kaon ug transpo
ibutang total_expenses = idugang expense1 ug expense2

// Calculate remaining money
ibutang savings = ikuha sweldo ug total_expenses
ipakita savings
""",

    "simple_interest.bai": """// Simple Interest Calculator
// Calculate interest earned

// Principal amount
ibutang principal = 10000

// Interest rate (5%)
ibutang rate = 5

// Time in years
ibutang years = 3

// Calculate interest: (P * R * T) / 100
ibutang step1 = ipilo principal ug rate
ibutang step2 = ipilo step1 ug years
ibutang interest = ibahin step2 ug 100

ipakita interest

// Calculate total amount
ibutang total = idugang principal ug interest
ipakita total
""",

    "tip_calculator.bai": """// Restaurant Tip Calculator
// Calculate tip and total bill

// Bill amount
ibutang bill = 1500

// Tip percentage (15%)
ibutang tip_percent = 15

// Calculate tip amount
ibutang tip_calc = ipilo bill ug tip_percent
ibutang tip = ibahin tip_calc ug 100
ipakita tip

// Calculate total with tip
ibutang total = idugang bill ug tip
ipakita total
""",

    "area_calculator.bai": """// Area Calculator
// Calculate area of rectangle

// Length and width
ibutang length = 15
ibutang width = 10

// Calculate area (length * width)
ibutang area = ipilo length ug width
ipakita area

// Calculate perimeter 2 * (length + width)
ibutang sum = idugang length ug width
ibutang perimeter = ipilo sum ug 2
ipakita perimeter
""",

    "temperature_converter.bai": """// Temperature Converter
// Convert Celsius to Fahrenheit
// Formula: F = (C * 9/5) + 32

// Temperature in Celsius
ibutang celsius = 25

// Convert to Fahrenheit
ibutang step1 = ipilo celsius ug 9
ibutang step2 = ibahin step1 ug 5
ibutang fahrenheit = idugang step2 ug 32

ipakita fahrenheit
"""
}

def create_sample_files():
    """Create all sample .bai files"""
    import os
    
    # Create samples folder
    folder = "sample_programs"
    if not os.path.exists(folder):
        os.makedirs(folder)
        print(f"✓ Created folder: {folder}/")
    
    # Create each sample file
    for filename, content in sample_programs.items():
        filepath = os.path.join(folder, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ Created: {filepath}")
    
    print(f"\n✓ Successfully created {len(sample_programs)} sample programs!")
    print(f"\nSample programs are in: {folder}/")
    print("\nYou can:")
    print("  1. Open these files in Bai++ IDE")
    print("  2. Run them to see how they work")
    print("  3. Modify them to learn Bai++")
    print("  4. Share them with your friends")

if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("Bai++ Sample Program Generator")
    print("=" * 50 + "\n")
    
    create_sample_files()
    
    print("\n" + "=" * 50)
    input("\nPress Enter to exit...")