import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import re

class BaiInterpreter:
    def __init__(self):
        self.variables = {}
        self.output = []
    
    def tokenize(self, line):
        """Break line into tokens"""
        line = line.split('//')[0].strip()
        if not line:
            return []
        tokens = line.split()
        return tokens
    
    def evaluate_expression(self, tokens):
        """Evaluate a mathematical expression or variable"""
        if len(tokens) == 1:
            token = tokens[0]
            try:
                return float(token)
            except ValueError:
                if token in self.variables:
                    return self.variables[token]
                else:
                    raise Exception(f"Variable '{token}' dili pa gi-define (not defined)")
        
        if len(tokens) >= 3:
            operation = tokens[0]
            
            if operation in ['idugang', 'ikuha', 'ipilo', 'ibahin']:
                left_val = self.get_value(tokens[1])
                right_val = self.get_value(tokens[3]) if len(tokens) > 3 and tokens[2] == 'ug' else self.get_value(tokens[2])
                
                if operation == 'idugang':
                    return left_val + right_val
                elif operation == 'ikuha':
                    return left_val - right_val
                elif operation == 'ipilo':
                    return left_val * right_val
                elif operation == 'ibahin':
                    if right_val == 0:
                        raise Exception("Dili pwede mag-divide by zero! (Cannot divide by zero!)")
                    return left_val / right_val
        
        raise Exception(f"Sayop ang syntax (Wrong syntax): {' '.join(tokens)}")
    
    def get_value(self, token):
        """Get numeric value from token"""
        try:
            return float(token)
        except ValueError:
            if token in self.variables:
                return self.variables[token]
            else:
                raise Exception(f"Variable '{token}' dili pa gi-define (not defined)")
    
    def execute_line(self, line):
        """Execute a single line of Bai++ code"""
        tokens = self.tokenize(line)
        
        if not tokens:
            return None
        
        if tokens[0] == 'ibutang':
            if len(tokens) < 4 or tokens[2] != '=':
                raise Exception("Sayop ang format sa ibutang. Gamita: ibutang x = 5")
            
            var_name = tokens[1]
            expr_tokens = tokens[3:]
            value = self.evaluate_expression(expr_tokens)
            self.variables[var_name] = value
            return None
        
        elif tokens[0] == 'ipakita':
            if len(tokens) < 2:
                raise Exception("Ipakita unsa? (Show what?) Gamita: ipakita x")
            
            expr_tokens = tokens[1:]
            value = self.evaluate_expression(expr_tokens)
            self.output.append(str(value))
            return value
        
        elif tokens[0] in ['idugang', 'ikuha', 'ipilo', 'ibahin']:
            value = self.evaluate_expression(tokens)
            self.output.append(f"Resulta: {value}")
            return value
        
        else:
            raise Exception(f"Wala ma-kila ang command: {tokens[0]}")
    
    def run(self, code):
        """Run complete Bai++ program"""
        self.output = []
        self.variables = {}
        
        lines = code.strip().split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            try:
                self.execute_line(line)
            except Exception as e:
                self.output.append(f"ERROR sa line {line_num}: {str(e)}")
                return '\n'.join(self.output)
        
        return '\n'.join(self.output) if self.output else "Program nahuman nga walay output"


class BaiPlusPlusIDE:
    def __init__(self, root):
        self.root = root
        self.root.title("Bai++ IDE - Bisaya Programming Language")
        self.root.geometry("1000x700")
        self.root.configure(bg="#2b2b2b")
        
        self.current_file = None
        self.interpreter = BaiInterpreter()
        
        # Create menu bar
        self.create_menu()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create main content area
        self.create_editor()
        
        # Create output panel
        self.create_output()
        
        # Load example code
        self.load_example()
    
    def create_menu(self):
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="Open", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        file_menu.add_command(label="Save As", command=self.save_file_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Run menu
        run_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Run", menu=run_menu)
        run_menu.add_command(label="Run Program", command=self.run_code, accelerator="F5")
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        help_menu.add_command(label="Bai++ Syntax", command=self.show_syntax_help)
        
        # Keyboard shortcuts
        self.root.bind("<Control-n>", lambda e: self.new_file())
        self.root.bind("<Control-o>", lambda e: self.open_file())
        self.root.bind("<Control-s>", lambda e: self.save_file())
        self.root.bind("<F5>", lambda e: self.run_code())
    
    def create_toolbar(self):
        toolbar = tk.Frame(self.root, bg="#3c3c3c", height=40)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        
        # Run button
        run_btn = tk.Button(toolbar, text="▶ Run (F5)", command=self.run_code, 
                           bg="#4CAF50", fg="white", font=("Arial", 11, "bold"),
                           padx=15, pady=5, relief=tk.FLAT, cursor="hand2")
        run_btn.pack(side=tk.LEFT, padx=10, pady=5)
        
        # New button
        new_btn = tk.Button(toolbar, text="📄 New", command=self.new_file,
                           bg="#555", fg="white", font=("Arial", 10),
                           padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        new_btn.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Open button
        open_btn = tk.Button(toolbar, text="📂 Open", command=self.open_file,
                            bg="#555", fg="white", font=("Arial", 10),
                            padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        open_btn.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Save button
        save_btn = tk.Button(toolbar, text="💾 Save", command=self.save_file,
                            bg="#555", fg="white", font=("Arial", 10),
                            padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        save_btn.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Clear output button
        clear_btn = tk.Button(toolbar, text="🗑 Clear Output", command=self.clear_output,
                             bg="#555", fg="white", font=("Arial", 10),
                             padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        clear_btn.pack(side=tk.RIGHT, padx=10, pady=5)
    
    def create_editor(self):
        editor_frame = tk.Frame(self.root, bg="#2b2b2b")
        editor_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Label
        label = tk.Label(editor_frame, text="Bai++ Code Editor", 
                        bg="#2b2b2b", fg="white", font=("Arial", 11, "bold"))
        label.pack(anchor=tk.W, pady=(0, 5))
        
        # Text editor with syntax highlighting
        self.text_editor = scrolledtext.ScrolledText(
            editor_frame,
            wrap=tk.WORD,
            bg="#1e1e1e",
            fg="#d4d4d4",
            insertbackground="white",
            font=("Consolas", 12),
            undo=True,
            relief=tk.FLAT,
            padx=10,
            pady=10
        )
        self.text_editor.pack(fill=tk.BOTH, expand=True)
        
        # Configure syntax highlighting tags
        self.text_editor.tag_config("keyword", foreground="#569CD6")
        self.text_editor.tag_config("comment", foreground="#6A9955")
        self.text_editor.tag_config("number", foreground="#B5CEA8")
        self.text_editor.tag_config("operator", foreground="#D4D4D4")
        
        # Bind key release for syntax highlighting
        self.text_editor.bind("<KeyRelease>", self.highlight_syntax)
    
    def create_output(self):
        output_frame = tk.Frame(self.root, bg="#2b2b2b")
        output_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, padx=5, pady=5)
        
        # Label
        label = tk.Label(output_frame, text="Output", 
                        bg="#2b2b2b", fg="white", font=("Arial", 11, "bold"))
        label.pack(anchor=tk.W, pady=(0, 5))
        
        # Output text area
        self.output_text = scrolledtext.ScrolledText(
            output_frame,
            wrap=tk.WORD,
            bg="#1e1e1e",
            fg="#00ff00",
            font=("Consolas", 11),
            height=10,
            relief=tk.FLAT,
            padx=10,
            pady=10,
            state=tk.DISABLED
        )
        self.output_text.pack(fill=tk.BOTH, expand=True)
    
    def highlight_syntax(self, event=None):
        """Simple syntax highlighting"""
        # Remove all tags
        self.text_editor.tag_remove("keyword", "1.0", tk.END)
        self.text_editor.tag_remove("comment", "1.0", tk.END)
        self.text_editor.tag_remove("number", "1.0", tk.END)
        
        content = self.text_editor.get("1.0", tk.END)
        
        # Highlight keywords
        keywords = ['ibutang', 'ipakita', 'idugang', 'ikuha', 'ipilo', 'ibahin', 'ug', 'kini']
        for keyword in keywords:
            start = "1.0"
            while True:
                pos = self.text_editor.search(r'\m' + keyword + r'\M', start, tk.END, regexp=True)
                if not pos:
                    break
                end = f"{pos}+{len(keyword)}c"
                self.text_editor.tag_add("keyword", pos, end)
                start = end
        
        # Highlight comments
        start = "1.0"
        while True:
            pos = self.text_editor.search("//", start, tk.END)
            if not pos:
                break
            end = f"{pos} lineend"
            self.text_editor.tag_add("comment", pos, end)
            start = f"{pos}+1line"
        
        # Highlight numbers
        for match in re.finditer(r'\b\d+\.?\d*\b', content):
            start_idx = f"1.0+{match.start()}c"
            end_idx = f"1.0+{match.end()}c"
            self.text_editor.tag_add("number", start_idx, end_idx)
    
    def run_code(self):
        """Execute the Bai++ code"""
        code = self.text_editor.get("1.0", tk.END)
        
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete("1.0", tk.END)
        
        try:
            output = self.interpreter.run(code)
            self.output_text.insert(tk.END, output)
        except Exception as e:
            self.output_text.insert(tk.END, f"ERROR: {str(e)}")
        
        self.output_text.config(state=tk.DISABLED)
    
    def clear_output(self):
        """Clear the output panel"""
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete("1.0", tk.END)
        self.output_text.config(state=tk.DISABLED)
    
    def new_file(self):
        """Create a new file"""
        if messagebox.askyesno("New File", "Clear current code?"):
            self.text_editor.delete("1.0", tk.END)
            self.current_file = None
            self.root.title("Bai++ IDE - Untitled")
    
    def open_file(self):
        """Open a .bai file"""
        file_path = filedialog.askopenfilename(
            defaultextension=".bai",
            filetypes=[("Bai++ Files", "*.bai"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
                    self.text_editor.delete("1.0", tk.END)
                    self.text_editor.insert("1.0", content)
                    self.current_file = file_path
                    self.root.title(f"Bai++ IDE - {file_path}")
                    self.highlight_syntax()
            except Exception as e:
                messagebox.showerror("Error", f"Cannot open file: {str(e)}")
    
    def save_file(self):
        """Save the current file"""
        if self.current_file:
            self.save_to_file(self.current_file)
        else:
            self.save_file_as()
    
    def save_file_as(self):
        """Save as a new file"""
        file_path = filedialog.asksaveasfilename(
            defaultextension=".bai",
            filetypes=[("Bai++ Files", "*.bai"), ("All Files", "*.*")]
        )
        
        if file_path:
            self.save_to_file(file_path)
            self.current_file = file_path
            self.root.title(f"Bai++ IDE - {file_path}")
    
    def save_to_file(self, file_path):
        """Save content to file"""
        try:
            content = self.text_editor.get("1.0", tk.END)
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(content)
            messagebox.showinfo("Success", "File saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Cannot save file: {str(e)}")
    
    def show_about(self):
        """Show about dialog"""
        messagebox.showinfo(
            "About Bai++",
            "Bai++ Programming Language\n\n"
            "A Bisaya-based programming language\n"
            "for simple calculations and learning.\n\n"
            "Version 1.0\n"
            "Created with ❤️"
        )
    
    def show_syntax_help(self):
        """Show syntax help"""
        help_text = """
Bai++ Syntax Guide
==================

Variables:
  ibutang x = 10          // Assign value to x
  ibutang y = 5           // Assign value to y

Operations:
  idugang x ug y          // Add (x + y)
  ikuha x ug y            // Subtract (x - y)
  ipilo x ug y            // Multiply (x * y)
  ibahin x ug y           // Divide (x / y)

Display:
  ipakita x               // Show value of x
  ipakita idugang x ug y  // Show result of x + y

Comments:
  // This is a comment

Example Program:
  // Calculator
  ibutang a = 100
  ibutang b = 25
  
  ipakita idugang a ug b  // Shows 125
  ipakita ikuha a ug b    // Shows 75
  ipakita ipilo a ug b    // Shows 2500
  ipakita ibahin a ug b   // Shows 4
"""
        
        help_window = tk.Toplevel(self.root)
        help_window.title("Bai++ Syntax Help")
        help_window.geometry("500x600")
        help_window.configure(bg="#2b2b2b")
        
        text_widget = scrolledtext.ScrolledText(
            help_window,
            wrap=tk.WORD,
            bg="#1e1e1e",
            fg="#d4d4d4",
            font=("Consolas", 10),
            padx=15,
            pady=15
        )
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        text_widget.insert("1.0", help_text)
        text_widget.config(state=tk.DISABLED)
    
    def load_example(self):
        """Load example code on startup"""
        example_code = """// Welcome to Bai++! Bisaya Programming Language
// Malipayon nga pag-program! (Happy programming!)

// Define variables
ibutang x = 50
ibutang y = 10

// Basic arithmetic operations
ipakita idugang x ug y    // Addition: 60
ipakita ikuha x ug y      // Subtraction: 40
ipakita ipilo x ug y      // Multiplication: 500
ipakita ibahin x ug y     // Division: 5

// Store results in variables
ibutang resulta = idugang x ug 25
ipakita resulta           // Shows: 75

// More calculations
ibutang total = ipilo resulta ug 2
ipakita total             // Shows: 150
"""
        self.text_editor.insert("1.0", example_code)
        self.highlight_syntax()


def main():
    root = tk.Tk()
    app = BaiPlusPlusIDE(root)
    root.mainloop()


if __name__ == "__main__":
    main()