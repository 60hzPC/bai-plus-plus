"""
Bai++ Build Script
This script creates a standalone executable for Bai++ IDE
"""

import os
import sys
import subprocess

def build_exe():
    print("=" * 50)
    print("Building Bai++ Executable")
    print("=" * 50)
    
    # Check if PyInstaller is installed
    try:
        import PyInstaller
        print("✓ PyInstaller found")
    except ImportError:
        print("✗ PyInstaller not found")
        print("\nInstalling PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("✓ PyInstaller installed successfully")
    
    # PyInstaller command
    cmd = [
        "pyinstaller",
        "--onefile",                    # Single executable file
        "--windowed",                   # No console window (GUI only)
        "--name=BaiPlusPlus",          # Name of the executable
        "--icon=NONE",                  # No icon (you can add one later)
        "--clean",                      # Clean cache
        "bai_ide.py"                   # Your main script
    ]
    
    print("\nBuilding executable...")
    print("This may take a few minutes...\n")
    
    try:
        subprocess.check_call(cmd)
        print("\n" + "=" * 50)
        print("✓ BUILD SUCCESSFUL!")
        print("=" * 50)
        print("\nYour executable is located at:")
        print("  → dist/BaiPlusPlus.exe")
        print("\nYou can now:")
        print("  1. Run dist/BaiPlusPlus.exe to test it")
        print("  2. Share dist/BaiPlusPlus.exe with your friends")
        print("  3. Upload it to GitHub releases")
        print("\nNote: The .exe file is about 15-20 MB")
        print("=" * 50)
        
    except subprocess.CalledProcessError as e:
        print("\n✗ Build failed!")
        print(f"Error: {e}")
        return False
    
    return True

def clean_build_files():
    """Clean up build artifacts"""
    print("\nCleaning up build files...")
    import shutil
    
    dirs_to_remove = ['build', '__pycache__']
    files_to_remove = ['BaiPlusPlus.spec']
    
    for d in dirs_to_remove:
        if os.path.exists(d):
            shutil.rmtree(d)
            print(f"  Removed: {d}/")
    
    for f in files_to_remove:
        if os.path.exists(f):
            os.remove(f)
            print(f"  Removed: {f}")
    
    print("✓ Cleanup complete")

if __name__ == "__main__":
    print("\n")
    print("╔════════════════════════════════════════════════╗")
    print("║        Bai++ Executable Builder v1.0          ║")
    print("║     Bisaya Programming Language Packager      ║")
    print("╚════════════════════════════════════════════════╝")
    print("\n")
    
    # Check if bai_ide.py exists
    if not os.path.exists("bai_ide.py"):
        print("✗ ERROR: bai_ide.py not found!")
        print("  Please make sure bai_ide.py is in the same folder.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    # Build the executable
    success = build_exe()
    
    if success:
        # Ask if user wants to clean up
        print("\n")
        response = input("Do you want to clean up build files? (y/n): ").lower()
        if response == 'y':
            clean_build_files()
    
    print("\n")
    input("Press Enter to exit...")